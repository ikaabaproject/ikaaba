﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Twitter")]
	public class MSP_TwitterFriedsidsRequest : FsmStateAction {
		
		public FsmEvent successEvent;
		public FsmEvent failEvent;
		
		public FsmString user_id;
		public FsmString[] ids;

		public override void OnEnter() {	
			TW_FriendsIdsRequest r = TW_FriendsIdsRequest.Create();
			r.ActionComplete += OnIdsLoaded;
			if (user_id.Value.Length > 0) {
				r.AddParam ("user_id", user_id.Value);
			}
			r.Send();
		}
		
		private void OnIdsLoaded(TW_APIRequstResult result) {		
			
			if(result.IsSucceeded) {
				ids = new FsmString[result.ids.Count];
				
				for(int i = 0; i < result.ids.Count; i++) {
					ids[i].Value = result.ids[i];
				}

				Fsm.Event(successEvent);
				Finish();
			} else {
				Fsm.Event(failEvent);
				Finish();
			}
		}
	}
}