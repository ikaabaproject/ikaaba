﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Facebook")]
	public class MSP_FB_Analitycs_SpentCredits : FsmStateAction {
		
		public FsmFloat credit;
		public FsmString contentType;
		public FsmString contentId;
		
		public override void OnEnter() {
			SPFacebookAnalytics.SpentCredits(credit.Value, contentType.Value, contentId.Value);
			Finish ();
		}		
	}
}
