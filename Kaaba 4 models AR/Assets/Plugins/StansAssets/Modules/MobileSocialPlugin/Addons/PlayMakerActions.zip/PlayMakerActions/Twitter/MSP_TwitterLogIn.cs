using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Twitter")]
	public class MSP_TwitterLogIn : FsmStateAction {

 
		public FsmEvent successEvent;
		public FsmEvent failEvent;
		

		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}

			if(SPTwitter.Instance.IsAuthed) {
				HandleOnAuthCompleteAction(null);
				return;
			}

			SPTwitter.Instance.Init();


			SPTwitter.Instance.OnAuthCompleteAction += HandleOnAuthCompleteAction;

			SPTwitter.Instance.AuthenticateUser();
		}

		void HandleOnAuthCompleteAction (TWResult res) {

			SPTwitter.Instance.OnAuthCompleteAction -= HandleOnAuthCompleteAction;

			if (SPTwitter.Instance.IsAuthed) {
				Fsm.Event (successEvent);
			} else {
				Fsm.Event(failEvent);
			}

			Finish ();
		}

	

	}
}


