﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Twitter")]
	public class MSP_TwitterCheckConnection : FsmStateAction {
		
		public FsmBool connection;
		
		public FsmEvent twitterConnected;
		public FsmEvent twitterDisconnected;
		
		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			connection.Value = SPTwitter.Instance.IsAuthed || IsInEdditorMode ? true : false;								
			
			Fsm.Event (connection.Value ? twitterConnected : twitterDisconnected);
			
			Finish ();
		}
	}
}
