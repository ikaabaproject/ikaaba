﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Facebook")]
	public class MSP_FB_Analitycs_Purchased : FsmStateAction {
		
		public FsmFloat price;
		public FsmInt itemsCount;
		public FsmString contentType;
		public FsmString contentId;
		public FsmString currency;
		
		public override void OnEnter() {
			SPFacebookAnalytics.Purchased(price.Value, itemsCount.Value, contentType.Value, contentId.Value, currency.Value);
			Finish ();
		}
		
		public override void Reset() {
			base.Reset();
			
			currency =  "USD";		
		}		
	}
}
